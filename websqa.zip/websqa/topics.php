<?php
/*
Author: Javed Ur Rehman
Website: http://www.allphptricks.com/
*/
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Web SQA</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/usim logoo.png" style="width:100px;height:100px;"type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-3 logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo"> <a href="index.php"><img src="images/isadroit_white 1.png" alt="#"></a> </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-9">
                  <div class="menu-area">
                     <div class="limit-box">
                        <nav class="main-menu">
                           <ul class="menu-area-main">
                              <li>
                                 <a href="index.php">Home</a>
                              </li>
                              <li>
                                 <a href="about.php">About</a>
                              </li>
                              <li class="active">
                                 <a href="topics.php">topics</a>
                              </li>
                              <li>
                                 <a href="assestment.php">assessment</a>
                              </li>
                              <li>
                                 <a href="contact.php">Feedback</a>
                              </li>
                              <li>
                               
                                 <a href="search.php"><img src="images/search_icon.png" alt="#" /></a>
                              </li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- end header inner -->
      </header>
      <!-- end header -->
      <div class="About-bg">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="aboutheading">
               <h3>Topics</h3>
            </div>
         </div>
      </div>
   </div>
</div>
      <!-- section --> 
      <div class="section layout_padding dark_bg">
         <div class="container">
            
            <div class="row">
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21113&amp;authkey=AIx6t2JucCfAF90&amp;em=2&amp;wdAr=1.331484049930652" width="609px" height="481px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3 class="white_font">TOPIC 1</h3>
                     <h5 class="grey_font">WEEK 1</h5>
                     <h3 class="white_font">The Software Quality Challenges</h3>
                  </div>
               </div>
            </div>
            
            </div>
         </div>
      </div>
      <!-- end section -->

       <!-- section --> 
      <div class="section layout_padding">
         <div class="container">
            
            <div class="row">
   <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3>TOPIC 2</h3>
                     <h5>WEEK 2</h5>
                     <h3>What Is Software Quality ??</h3>
                  </div>
               </div>
               <div class="col-md-6">
                  <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21123&amp;authkey=AMG7gzBwcG_U_Og&amp;em=2&amp;wdAr=1.331484049930652" width="721px" height="565px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               
            </div>
         </div>
      </div>
      <!-- end section -->
      <div class="section layout_padding dark_bg">
         <div class="container">
            
            <div class="row">
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21125&amp;authkey=AOtClRWO3m70EYk&amp;em=2&amp;wdAr=1.4148802017654476" width="610px" height="455px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3 class="white_font">TOPIC 3</h3>
                     <h5 class="grey_font">WEEK 3</h5>
                     <h3 class="white_font">Software Quality Factors</h3>
                  </div>
               </div>
            </div>
            
            </div>
         </div>
      </div>

      <div class="section layout_padding">
         <div class="container">
            
            <div class="row">
   <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3>TOPIC 4</h3>
                     <h5>WEEK 4</h5>
                     <h3>Contract Review</h3>
                  </div>
               </div>
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21124&amp;authkey=AMyUhqXIcSwmbnk&amp;em=2&amp;wdAr=1.4148802017654476" width="610px" height="455px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               
            </div>
         </div>
      </div>

      <div class="section layout_padding dark_bg">
         <div class="container">
            
            <div class="row">
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21126&amp;authkey=AJ7diuQo7hl0g-Y&amp;em=2&amp;wdAr=1.4148802017654476" width="610px" height="455px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3 class="white_font">TOPIC 5</h3>
                     <h5 class="grey_font">WEEK 5</h5>
                     <h3 class="white_font">Software Quality Plan</h3>
                  </div>
               </div>
            </div>
            
            </div>
         </div>
      </div>

      <div class="section layout_padding">
         <div class="container">
            
            <div class="row">
   <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3>TOPIC 6</h3>
                     <h5>WEEK 6</h5>
                     <h3>Design Reviews</h3>
                  </div>
               </div>
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21127&amp;authkey=AEP-i7FvGSGWbLc&amp;em=2&amp;wdAr=1.4148802017654476" width="610px" height="455px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               
            </div>
         </div>
      </div>

      <div class="section layout_padding dark_bg">
         <div class="container">
            
            <div class="row">
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21128&amp;authkey=AMeB5DiI7GvgL8I&amp;em=2&amp;wdAr=1.4148802017654476" width="610px" height="455px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3 class="white_font">TOPIC 7</h3>
                     <h5 class="grey_font">WEEK 7</h5>
                     <h3 class="white_font">Software Testing - Strategies</h3>
                  </div>
               </div>
            </div>
            
            </div>
         </div>
      </div>

      <div class="section layout_padding">
         <div class="container">
            
            <div class="row">
   <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3>TOPIC 8</h3>
                     <h5>WEEK 8</h5>
                     <h3>Software Testing - Implementation</h3>
                  </div>
               </div>
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21129&amp;authkey=AHLSPyhItVNuuUs&amp;em=2&amp;wdAr=1.3333333333333333" width="610px" height="481px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               
            </div>
         </div>
      </div>

      <div class="section layout_padding dark_bg">
         <div class="container">
            
            <div class="row">
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21132&amp;authkey=AMVkWlWFQclMYHY&amp;em=2&amp;wdAr=1.3333333333333333" width="610px" height="481px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3 class="white_font">TOPIC 9</h3>
                     <h5 class="grey_font">WEEK 9</h5>
                     <h3 class="white_font">Assuring The Quality Of Software Maintenance Components</h3>
                  </div>
               </div>
            </div>
            
            </div>
         </div>
      </div>

      <div class="section layout_padding">
         <div class="container">
            
            <div class="row">
   <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3>TOPIC 10</h3>
                     <h5>WEEK 10</h5>
                     <h3>Procedures And Work Instructions</h3>
                  </div>
               </div>
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21118&amp;authkey=ABqtIfgYUVIkQz8&amp;em=2&amp;wdAr=1.3333333333333333" width="610px" height="481px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               
            </div>
         </div>
      </div>

      <div class="section layout_padding dark_bg">
         <div class="container">
            
            <div class="row">
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21119&amp;authkey=AOvAutNpz4xz_tI&amp;em=2&amp;wdAr=1.7777777777777777" width="610px" height="481px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3 class="white_font">TOPIC 11</h3>
                     <h5 class="grey_font">WEEK 11</h5>
                     <h3 class="white_font">Documentation Control - Supporting Quality Devices</h3>
                  </div>
               </div>
            </div>
            
            </div>
         </div>
      </div>

      <div class="section layout_padding">
         <div class="container">
            
            <div class="row">
   <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3>TOPIC 12</h3>
                     <h5>WEEK 12</h5>
                     <h3>Configuration Management</h3>
                  </div>
               </div>
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?resid=5924495DC69BDD04%21121&amp;authkey=%21AL7RDt7pCu4kvas&amp;em=2&amp;wdAr=1.3333333333333333" width="610px" height="481px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               
            </div>
         </div>
      </div>

      <div class="section layout_padding dark_bg">
         <div class="container">
            
            <div class="row">
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21122&amp;authkey=AN2ku95FyD3JaFA&amp;em=2&amp;wdAr=1.7777777777777777" width="610px" height="481px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3 class="white_font">TOPIC 13</h3>
                     <h5 class="grey_font">WEEK 13</h5>
                     <h3 class="white_font">SQA Architecture</h3>
                  </div>
               </div>
            </div>
            
            </div>
         </div>
      </div>
      <!-- footer -->
      <footer>
         <div class="container">
            <div class="row">
               <div class="col-lg-4 col-md-6">
                  <a href="#"><img src="images/isadroit(white).jpg" alt="#" style="width:300px;height:200px;" /></a>
                  <ul class="contact_information">
                     <li><span><img src="images/location_icon.png" alt="#" /></span><span class="text_cont">Universiti Sains<br>Islam Malaysia</span></li>
                     <li><span><img src="images/phone_icon.png" alt="#" /></span><span class="text_cont">019-4970590<br>019-6789359</span></li>
                     <li><span><img src="images/mail_icon.png" alt="#" /></span><span class="text_cont">demo@gmail.com<br>support@gmail.com</span></li>
                  </ul>
                  <ul class="social_icon">
                     <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                     <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  </ul>
               </div>
               <div class="col-lg-2 col-md-6">
                  <div class="footer_links">
                     <h3>Quick link</h3>
                     <ul>
                        <li><a href="index.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Home</a></li>
                        <li><a href="about.php"><i class="fa fa-angle-right" aria-hidden="true"></i> About</a></li>
                        <li><a href="topics.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Topics</a></li>
                        <li><a href="assetment.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Assessment</a></li>
                        <li><a href="contact.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Feedback</a></li>
                     </ul>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6">
                  <div class="footer_links">
                     <h3>Instagram</h3>
                     <ol>
                        <li><img class="img-responsive" src="images/insta logo.png" alt="#" style="width:100px;height:100px;" /></li>
                        <li><img class="img-responsive" src="images/insta logo.png" alt="#" style="width:100px;height:100px;"/></li>
                        <li><img class="img-responsive" src="images/insta logo.png" alt="#" style="width:100px;height:100px;"/></li>
                        <li><img class="img-responsive" src="images/insta logo.png" alt="#" style="width:100px;height:100px;"/></li>
                     </ol>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6">
                  <div class="footer_links">
                     <h3>Contact us</h3>
                     <form action="index.php">
                        <fieldset>
                           <div class="field">
                              <input type="text" name="name" placeholder="Your Name" required="" />
                           </div>
                           <div class="field">
                              <input type="email" name="email" placeholder="Email" required="" />
                           </div>
                           <div class="field">
                              <input type="text" name="subject" placeholder="Subject" required="" />
                           </div>
                           <div class="field">
                              <textarea placeholder="Message"></textarea>
                           </div>
                           <div class="field">
                              <div class="center">
                                 <button class="reply_bt">Send</button>
                              </div>
                           </div>
                        </fieldset>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <div class="cpy">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <p>Copyright © 2019 Design by <a href="https://html.design/">Free Html Templates</a></p>
               </div>
            </div>
         </div>
      </div>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- Scrollbar Js Files -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>
<?php
/*
Author: Javed Ur Rehman
Website: http://www.allphptricks.com/
*/
?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Web SQA</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/usim logoo.png" style="width:100px;height:100px;"type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-3 logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo"> <a href="index.php"><img src="images/isadroit_white 1.png" alt="#"></a> </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-9">
                  <div class="menu-area">
                     <div class="limit-box">
                        <nav class="main-menu">
                           <ul class="menu-area-main">
                              <li class="active">
                                 <a href="index.php">Home</a>
                              </li>
                              <li>
                                 <a href="about.php">About</a>
                              </li>
                              <li>
                                 <a href="topics.php">topics</a>
                              </li>
                              <li>
                                 <a href="assestment.php">assessment</a>
                              </li>
                              <li>
                                 <a href="contact.php">Feedback</a>
                              </li>
                              <li>
                               
                                 <a href="search.php"><img src="images/search_icon.png" alt="#" /></a>
                              </li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- end header inner -->
      </header>
      <!-- end header -->
      <!-- revolution slider -->
      <div class="banner-slider">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-7">
                  <div id="slider_main" class="carousel slide" data-ride="carousel">
                     <!-- The slideshow -->
                     <div class="carousel-inner">
                        <div class="carousel-item active">
                           <img src="images/sqa3.png" alt="First slide" style="width:8000px;height:500px;" />
                        </div>
                        <div class="carousel-item">
                           <img src="images/sqa1.jpg" alt="Second slide" style="width:800px;height:500px;"/>
                        </div>
                        <div class="carousel-item">
                           <img src="images/sqa4.png" alt="Third slide" style="width:800px;height:500px;" />
                        </div>
                     </div>
                     <!-- Left and right controls -->
                     <a class="carousel-control-prev" href="#slider_main" data-slide="prev">
                     <i class="fa fa-angle-left" aria-hidden="true"></i>
                     </a>
                     <a class="carousel-control-next" href="#slider_main" data-slide="next">
                     <i class="fa fa-angle-right" aria-hidden="true"></i>
                     </a>
                  </div>
               </div>
              
               <div class="col-md-5">
                  <div class="full slider_cont_section">
                     <h4>SKJ3153</h4>
                     <h3>Software Quality Assurance</h3>
                     <p>A process which assures that all software engineering processes, methods, activities and work items are monitored and comply against the defined standards. These defined standards could be one or a combination of any like ISO 9000, CMMI model, ISO15504, etc.</p>
                     <div class="button_section">
                        <a href="about.php">Read More</a>
                        <a href="contact.php">Contact Us</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end revolution slider -->
      <!-- section --> 
      <div class="section layout_padding">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="heading">
                     <h3>About <span class="orange_color">SQA</span></h3>
                  </div>
               </div>
            </div>
            
            <div class="section layout_padding">
         <div class="container">
           
         <div class="section layout_padding blog_blue_bg light_silver">
         <div class="container">
            
            <div class="row">
               <div class="col-md-8 offset-md-2">
                  <div class="full">
                     <div class="big_blog">
                     <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21116&amp;authkey=AAIhzJWcfv0a7NY&amp;em=2" width="750px" height="400px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
                     </div>
                     <div class="blog_cont_2">
                        <h3>Course Outline SKJ4123</h3>
                        <p class="sublittle">Software Quality Assurance SKJ3153</p>
                        <p></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>

            <div class="row margin_top_30">
               <div class="col-md-12">
                  <div class="button_section full center margin_top_30">
                     <a style="margin:0;" href="about.php">Read More</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end section -->
      <!-- section --> 
      <div class="section layout_padding dark_bg">
         <div class="container">
            
            <div class="row">
               <div class="col-md-6">
               <iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21113&amp;authkey=AIx6t2JucCfAF90&amp;em=2&amp;wdAr=1.331484049930652" width="580px" height="481px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> presentation, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>
               </div>
               <div class="col-md-6">
                  <div class="full blog_cont">
                     <h3 class="white_font">TOPIC 1</h3>
                     <h5 class="grey_font">WEEK 1</h5>
                     <h3 class="white_font">The Software Quality Challenges</h3>
                  </div>
               </div>
            </div>
            <div class="row margin_top_30">
            </div>
         </div>
      </div>
      <div class="col-md-12">
                  <div class="button_section full center margin_top_30">
                     <a style="margin:0;" href="topics.php">Learn More</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      
      <!-- end section -->
      <!-- section --> 
      <div class="section layout_padding blog_blue_bg light_silver">
         <div class="container">
            <div class="row">
               <div class="col-md-8 offset-md-2">
                  <div class="heading">
                     <h3>Assessment</h3>
                  </div>
               </div>
            </div>
            <div class="section layout_padding blog_blue_bg light_silver">
         <div class="container">
            
            <div class="row">
               <div class="col-md-8 offset-md-2">
                  <div class="full">
                     <div class="big_blog">
                        <<iframe src="https://onedrive.live.com/embed?cid=5924495DC69BDD04&amp;resid=5924495DC69BDD04%21149&amp;authkey=AP_9suoInPjrXY0&amp;em=2" width="780px" height="400px" frameborder="0">This is an embedded <a target="_blank" href="https://office.com">Microsoft Office</a> document, powered by <a target="_blank" href="https://office.com/webapps">Office</a>.</iframe>>
                     </div>
                     <div class="blog_cont_2">
                        <h3>Exercise 2</h3>
                        <p class="sublittle">Week 2</p>
                        <p>Introduction To SQA</p>
                     </div>
                  </div>
               </div>
            <div class="col-md-12">
                  <div class="button_section full center margin_top_30">
                     <a style="margin:0;" href="assestment.php">Exercise More</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
         </div>
      </div>
      
      <!-- end section -->
      <!-- footer -->
      <footer>
         <div class="container">
            <div class="row">
               <div class="col-lg-4 col-md-6">
                  <a href="#"><img src="images/isadroit(white).jpg" alt="#" style="width:300px;height:200px;" /></a>
                  <ul class="contact_information">
                     <li><span><img src="images/location_icon.png" alt="#" /></span><span class="text_cont">Universiti Sains<br>Islam Malaysia</span></li>
                     <li><span><img src="images/phone_icon.png" alt="#" /></span><span class="text_cont">019-4970590<br>019-6789359</span></li>
                     <li><span><img src="images/mail_icon.png" alt="#" /></span><span class="text_cont">demo@gmail.com<br>support@gmail.com</span></li>
                  </ul>
                  <ul class="social_icon">
                     <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                     <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                  </ul>
               </div>
               <div class="col-lg-2 col-md-6">
                  <div class="footer_links">
                     <h3>Quick link</h3>
                     <ul>
                        <li><a href="index.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Home</a></li>
                        <li><a href="about.php"><i class="fa fa-angle-right" aria-hidden="true"></i> About</a></li>
                        <li><a href="topics.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Topics</a></li>
                        <li><a href="assestment.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Assessment</a></li>
                        <li><a href="contact.php"><i class="fa fa-angle-right" aria-hidden="true"></i> Feedback</a></li>
                     </ul>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6">
                  <div class="footer_links">
                     <h3>Instagram</h3>
                     <ol>
                        <li><img class="img-responsive" src="images/insta logo.png" alt="#" style="width:100px;height:100px;" /></li>
                        <li><img class="img-responsive" src="images/insta logo.png" alt="#" style="width:100px;height:100px;"/></li>
                        <li><img class="img-responsive" src="images/insta logo.png" alt="#" style="width:100px;height:100px;"/></li>
                        <li><img class="img-responsive" src="images/insta logo.png" alt="#" style="width:100px;height:100px;"/></li>
                     </ol>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6">
                  <div class="footer_links">
                     <h3>Contact us</h3>
                     <form action="index.php">
                        <fieldset>
                           <div class="field">
                              <input type="text" name="name" placeholder="Your Name" required="" />
                           </div>
                           <div class="field">
                              <input type="email" name="email" placeholder="Email" required="" />
                           </div>
                           <div class="field">
                              <input type="text" name="subject" placeholder="Subject" required="" />
                           </div>
                           <div class="field">
                              <textarea placeholder="Message"></textarea>
                           </div>
                           <div class="field">
                              <div class="center">
                                 <button class="reply_bt">Send</button>
                              </div>
                           </div>
                        </fieldset>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <div class="cpy">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <p>Copyright © 2019 Design by <a href="https://html.design/">Free Html Templates</a></p>
               </div>
            </div>
         </div>
      </div>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- Scrollbar Js Files -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>